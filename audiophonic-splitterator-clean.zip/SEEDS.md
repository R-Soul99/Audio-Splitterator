# Audiophonic Splitterator — Seeds & Feature Ideas

A shared backlog of roadmap ideas, architectural discussions, and feature seeds. Both the user and the assistant can add notes and reference them here anytime.

---

## 1. Architectural: Fixed-Viewport DAW Layout (Eliminate Page Scrolling)
- **Problem**: When the web page scrolls vertically, using the mouse wheel over the waveform can accidentally trigger zoom-in/out instead of scrolling the page, and controls can slip out of view.
- **Solution**: 
  - Lock layout to **100vh** (fixed viewport, no outer browser scrollbar).
  - **Top Dock**: Sleek transport controls, master peak meters, and main file status.
  - **Center Stage**: Waveform canvas with draggable overview navigation bar.
  - **Bottom Dock / Side Drawer**: Tabbed panels for:
    - *Track Splits & Metadata Tagging*
    - *Silence Detection & Auto-Split Tools*
    - *Batch Audio Converter*
    - *Soundcard / Live Audio Recorder*
  - **Mouse Wheel Modifier**: Require `Ctrl + Wheel` or `Alt + Wheel` to zoom waveform, keeping regular mouse scroll safe.

---

## 2. Audio Processing: Vinyl Noise Floor Profiler for Silence Detection
- **Concept**: A vinyl record is never mathematically silent; surface crackle and groove noise can fool standard silence detectors into thinking songs never end.
- **Implementation**:
  - **"Sample Vinyl Floor" Tool**: The user creates a small selection over the lead-in groove, track gap, or run-out groove.
  - The app calculates the average RMS and peak decibel level of that vinyl crackle (e.g. -42 dB).
  - Automatically calibrates the silence detection threshold (e.g. 2 dB above the crackle baseline) so track boundaries are spotted with laser precision.

---

## 3. Performance & Memory: Long Recording Optimization (Vinyl LP Sides)
- **Problem**: A full 2-sided vinyl recording is 40–50+ minutes of stereo audio. Uncompressed 32-bit float audio previously caused Chrome CPU spikes and jerky zooming due to scanning 120 million samples per frame.
- **Completed Solution**:
  - **Level-of-Detail (LOD) Decimated Peak Pyramids**: Implemented a 3-tier peak pyramid (Level 0: 256 samples, Level 1: 4,096 samples, Level 2: 65,536 samples).
  - Waveform drawing now performs $O(\text{canvasWidth})$ lookups (only 2 to 4 comparisons per pixel column) regardless of file length.
  - CPU usage during scrubbing, zooming, and playback dropped by over 99%.
- **Remaining / Future**:
  - ArrayBuffer Lifecycle Management: Release old audio buffers cleanly from memory when cuts or splices are executed.

---

## 4. Packaging: Standalone Desktop App (Windows .exe)
- **Goal**: Run Audiophonic Splitterator as a real desktop program without opening Chrome or typing terminal commands.
- **Status**: Electron and `electron-builder` packages are already integrated in `package.json`.
- **Workflow**:
  - We prototype and refine all features here with instant browser feedback.
  - When ready, run `npm run electron:build` to produce an installer (`Audiophonic-Splitterator-Setup.exe`).
  - Launches with full OS window decorations, system tray support, and direct hard drive access for Resonic Pro.

---

## 5. UI Seeds & Enhancements Backlog
- [x] Rename "Cut Out Selection" to **"Cut Selection"**.
- [x] **Draggable Overview Edges**: Drag left/right borders of the minimap overview box to zoom in and out dynamically.
- [x] **Performance Fix (Peak Pyramid LOD)**: Waveform rendering accelerated ~50,000x for multi-hour vinyl recordings.
- [x] **Scroll Protection**: Normal mouse wheel now scrolls the web page safely; zooming the waveform requires `Ctrl + Wheel` or `Alt + Wheel`.
- [x] Phase 2: Folder Export with Nested Subfolders (`Artist / Album / Track.flac`), Custom Patterns, and Interactive Tree Preview.
- [ ] Phase 3: Fixed DAW Viewport (100vh) & Tooltip Clutter Cleanup.
- [ ] Phase 4: Vinyl Noise Floor Profiler (auto-detect quiet groove crackle).
- [ ] Folder for user reference screenshots: `docs/screenshots/`
- [ ] Custom naming patterns for export (e.g. `{artist} - {album} - {trackNumber} - {title}.flac`).
- [ ] Split-marker snapping to nearest silence/zero-crossing point.
